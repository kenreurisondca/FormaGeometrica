#include "FormaGeometrica.cpp"

class Triangulo : public FormaGeometrica{
	public:
		Triangulo(char* n) : FormaGeometrica(n) {
			
		}
};
