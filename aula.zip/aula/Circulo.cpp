#include "FormaGeometrica.cpp"

class Circulo : public FormaGeometrica {
	public:
		Circulo(char* n) : FormaGeometrica(n) {
			
		}
};
