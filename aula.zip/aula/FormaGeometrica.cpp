#ifndef FORMAGEOMETRICA_CPP
#define FORMAGEOMETRICA_CPP
class FormaGeometrica {
	protected:
		char* nome;
		float area;
		float perimetro;
	
	public:
		
	FormaGeometrica(){
		
	}
	FormaGeometrica(char* n){
		nome = n;
	}
	
	char* getNome(){
		return nome;
	}
};
#endif
