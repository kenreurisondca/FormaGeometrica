class FormaGeometrica {
	protected:
		char* nome;
		float area;
		float perimetro;
	
	public:
		
	FormaGeometrica(){
		
	}
	FormaGeometrica(char* n){
		nome = n;
	}
};
