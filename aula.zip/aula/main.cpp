#include "Circulo.cpp"
#include "Triangulo.cpp"
#include <iostream>

using namespace std;

int main(){
	Circulo *c = new Circulo("C1");
	Triangulo *t = new Triangulo("T1");
	
	cout << c -> getNome();
	cout << endl;
	cout << t -> getNome();
	
}
